/****************************************************************************/
/*  farmemory.c v6.1.0                                                       */
/*                                                                          */
/* Copyright (c) 1993-2012 Texas Instruments Incorporated                   */
/* http://www.ti.com/                                                       */
/*                                                                          */
/*  Redistribution and  use in source  and binary forms, with  or without   */
/*  modification,  are permitted provided  that the  following conditions   */
/*  are met:                                                                */
/*                                                                          */
/*     Redistributions  of source  code must  retain the  above copyright   */
/*     notice, this list of conditions and the following disclaimer.        */
/*                                                                          */
/*     Redistributions in binary form  must reproduce the above copyright   */
/*     notice, this  list of conditions  and the following  disclaimer in   */
/*     the  documentation  and/or   other  materials  provided  with  the   */
/*     distribution.                                                        */
/*                                                                          */
/*     Neither the  name of Texas Instruments Incorporated  nor the names   */
/*     of its  contributors may  be used to  endorse or  promote products   */
/*     derived  from   this  software  without   specific  prior  written   */
/*     permission.                                                          */
/*                                                                          */
/*  THIS SOFTWARE  IS PROVIDED BY THE COPYRIGHT  HOLDERS AND CONTRIBUTORS   */
/*  "AS IS"  AND ANY  EXPRESS OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT   */
/*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   */
/*  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT   */
/*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   */
/*  SPECIAL,  EXEMPLARY,  OR CONSEQUENTIAL  DAMAGES  (INCLUDING, BUT  NOT   */
/*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   */
/*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   */
/*  THEORY OF  LIABILITY, WHETHER IN CONTRACT, STRICT  LIABILITY, OR TORT   */
/*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   */
/*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    */
/*                                                                          */
/****************************************************************************/

/*****************************************************************************/
/*                                                                           */
/*  This module contains the functions which implement the dynamic memory    */
/*  management routines when the heap is located in far memory.  The         */
/*  algorithms used are based on the algorithms described in Knuth's "The    */
/*  Art Of Computer Programming, Vol 1" on pages 435-441.                    */
/*  Algorithm 2.5A has been modified to improve the resistance to            */
/*  fragmentation.                                                           */
/*                                                                           */
/*  Knuth gives two reasons for prefering "first fit" over "best fit".       */
/*   1) The algorithm is significantly faster, since the whole of the free   */
/*      store does not have to be seached for each allocation                */
/*      (or deallocation).                                                   */
/*   2) The first fit algorithm is more resistant to overflow during         */
/*      repeated allocation and deallocation than is the best fit algorithm  */
/*      (See problems 36-43 on page 456).                                    */
/*                                                                           */
/*  The following assumptions/rules apply:                                   */
/*                                                                           */
/*                                                                           */
/*   1) Packets are allocated a minimum of two words                         */
/*   2) The heap can be reset at any time by calling the function            */
/*      "far_minit"                                                          */
/*   3) There a separate far heap.  Malloc and related routines will only    */
/*      affect allocations from the near heap                 .              */
/*   4) The far heap size must be declared in the linker command file using  */
/*      the -farheap option.                                                 */
/*                                                                           */
/*  The following items are defined in this module :                         */
/*   far_minit()    : Function to initialize dynamic memory management       */
/*   far_malloc()   : Function to allocate memory from mem mgmt system.      */
/*   far_calloc()   : Allocate and clear memory from mem mgmt system.        */
/*   far_realloc()  : Reallocate a packet                                    */
/*   far_free()     : Function to free allocated memory.                     */
/*                                                                           */
/*   far_memlcpy()   : long copy memory from one area to another             */
/*   far_memlmove()  : long copy memory from one area to another allowing    */
/*                     for overlapping regions                               */
/*                                                                           */
/*    _far_sys_memory : Array to contain all memory allocate by system.      */
/*    far_sys_free   : Pointer to free list                                  */
/*                                                                           */
/*    far_free_memory() : Return total amount of available free memory.      */
/*    far_max_free() : Return largest single free memory block in heap.      */
/*                                                                           */
/*****************************************************************************/

/*****************************************************************************/
/*  DEBUG Support.                                                           */
/*  When the symbol DEBUG has been #defined, an extra DWORD is added to the  */
/*  allocation header, and is set to the value 0xBEEFDEAD (so that it shows  */
/*  in the debugger as "dead beef") in every allocated and free block of     */
/*  memory.  The integrety of the far memory hep can then be checked by      */
/*  calling the function "long  far_chkheap()".  This function returns zero  */
/*  if the all memory blocks have the correct signature.  Otherwise, it      */
/*  returns the offset to the first location of an invalid value in a block  */
/*  header.                                                                  */
/*****************************************************************************/

#undef _INLINE				/* DISABLE INLINE EXPANSION         */

#include <string.h>
#include <stdlib.h>
#include <stddef.h>
#include <_lock.h>

#ifdef DEBUG
#define GUARDDWORD 0xBEEFDEAD
#endif

/*****************************************************************************/
/* Declare the memory pool as a .usect called .esysmem.  The size of the     */
/* section .esysmem is determined by the linker via the -farheap option      */
/*****************************************************************************/
#pragma DATA_SECTION(_far_sys_memory, ".esysmem")
far int _far_sys_memory[];

/*****************************************************************************/
/* "FPACKET" is the template for a far data packet.  Packet size contains    */
/* the number of words allocated for the user, excluding the size            */
/* required for management of the packet (32 bits).  Packets are always      */
/* allocated memory in words.  A negative size indicates a free packet.      */
/*****************************************************************************/
typedef struct fpack
{
	long packet_size;         /* in words */
#ifdef DEBUG
	long guard;
#endif
	far struct fpack  *size_ptr;
} FPACKET;


#define LIMIT	((far FPACKET *) -1)

#define OVERHEAD offsetof(FPACKET, size_ptr)
#define MINSIZE	2

/*****************************************************************************/
/* __FAR_SYSMEM_SIZE is the symbol that linker defines as the size of heap.  */
/* Access of that value from 'C' is done by taking the address of this symbol*/
/*****************************************************************************/
extern far int _FAR_SYSMEM_SIZE;
#define MEMORY_SIZE ((long)&_FAR_SYSMEM_SIZE)

/*****************************************************************************/
/* POINTER TO THE LIST OF FREE BLOCKS                                        */
/*****************************************************************************/
static far FPACKET * far_sys_free;

/*****************************************************************************/
/* POINTER TO THE START OF THE FAR HEAP                                      */
/*****************************************************************************/
static far FPACKET * far_sys_base;
static long memsize;
/*****************************************************************************/
/* FLAG TO TELL MALLOC IF THE MEMORY AREA HAS BEEN INITIALIZED 		     */
/*****************************************************************************/
static int first_call = 1; 

/*****************************************************************************/
/*                                                                           */
/*  FAR_MINIT - This function can be called by the user to completely reset  */
/*              the memory management system.                                */
/*                                                                           */
/*****************************************************************************/
void far_minit(void)
{
    _lock();
    memsize = MEMORY_SIZE;

    /************************************************************************/
    /* TO INITIALIZE THE MEMORY SYSTEM, DEALLOCATE ONE PACKET WHICH USES    */
    /* AVAILABLE MEMORY, INITIALIZE THE FREE LIST TO POINT TO IT.           */
    /* INSURE CORRECT ALIGNMENT BY MAKING SURE SYS_FREE IS ON AN EVEN       */
    /* BOUNDARY.  THIS GUARANTEES FIRST PACKET WILL BE ON AN EVEN BOUNDARY. */
    /************************************************************************/
    if ((long)_far_sys_memory & 1)
    {

	far_sys_free = (far FPACKET *) (_far_sys_memory + 1);
	-- memsize;
    }
    else
    {
	far_sys_free = (far FPACKET *) _far_sys_memory;
    }
    if(memsize & 1) --memsize;

    far_sys_free->packet_size = -(memsize - OVERHEAD);
    far_sys_free->size_ptr    = LIMIT;

#ifdef DEBUG
    far_sys_free->guard = GUARDDWORD;
#endif
    far_sys_base = far_sys_free;

    first_call = 0; 	/* Clear the flag */
    _unlock();
}

/*****************************************************************************/
/*                                                                           */
/*  FAR_MALLOC - Allocate a packet of a given size, and return pointer to    */
/*  it.  This function only allocates in multiple of ints.                   */
/*                                                                           */
/*****************************************************************************/
far void *far_malloc(unsigned long usersize)
{
    far FPACKET * current;
    far FPACKET * next;
    far FPACKET * last;

    if( usersize == 0 ) return 0;

    if(usersize & 1) ++usersize;   /* MAKE SURE THE SIZE IS EVEN */

    _lock();

    if(first_call) far_minit(); 

    current = far_sys_free;
    last = 0;

    if (current == LIMIT) { _unlock(); return 0; } /* NO MEMORY TO ALLOCATE */

    /*************************************************************************/
    /* LOOK FOR THE FIRST BLOCK LARGE ENOUGH TO HOLD THE REQUESTED ALLOCATION*/
    /*************************************************************************/
    while( -current->packet_size < usersize )
    {
    	last = current;
    	current = current->size_ptr;
    	if (current == LIMIT) 
	{
	    _unlock();
	    return 0; /* have tried all of free memory */
	}
    }

    if( -current->packet_size > usersize + OVERHEAD + MINSIZE )
    {
	/*********************************************************************/
	/* IF THE PACKET IS LARGER THAN NEEDED, SPLIT THE BLOCK AND ALLOCATE */
        /* THE BOTTOM PART.			    			     */
	/* tHIS IS THE MODIFICATION TO kNUTH'S ALGORITHM 2.5a. THE 	     */
	/* ALLOCATION OF THE LOW PART WAS CHOSEN IN PLACE OF SEARCHING FOR   */
	/* FUTURE ALLOCATIONS FROM SOME POINT WITHIN THE LIST (kNUTH'S 2.5a')*/
	/* AS A WAY TO ENSURE THAT FREED BLOCKS GET RECYCLED BEFORE          */
	/* ALLOCATIONS ARE MADE FROM THE LARGE ORIGINAL FREE BLOCK.          */
	/*********************************************************************/
	next = (far FPACKET *)((far char *)current + OVERHEAD + usersize);
	next->packet_size = current->packet_size + usersize + OVERHEAD;
#ifdef DEBUG
	next->guard = GUARDDWORD;
#endif
	current->packet_size = usersize;
	if(last)
	    last->size_ptr = next;
	else
	    far_sys_free = next;
	next->size_ptr = current->size_ptr;
    }
    else
    {
	/*********************************************************************/
	/* ALLOCATE THE WHOLE BLOCK AND REMOVE IT FROM THE FREE LIST.        */
	/*********************************************************************/
	if(last)
	    last->size_ptr = current->size_ptr;
	else
	    far_sys_free = current->size_ptr;

	current->packet_size = - current->packet_size;	/* FIX THE SIGN */
    }
    _unlock();
    return &(current->size_ptr);
}

/*****************************************************************************/
/*                                                                           */
/* FAR_FREE - Return a packet allocated by malloc to free memory pool.       */
/*                                                                           */
/*****************************************************************************/
void far_free(far void * userptr)
{
    far FPACKET * current;
    far FPACKET * next;
    far FPACKET * last;

    if( userptr == 0 ) return;		/* HANDLE NULL POINTER CORRECTLY */

    _lock();

    current = far_sys_free;
    last = 0;
    next = (far FPACKET *)((far char *) userptr - OVERHEAD);

    /*************************************************************************/
    /* SEARCH THE FREE LIST FOR THE FREE PACKETS IMMEDIATELY BEFORE AND AFTER*/
    /* THE PACKET TO BE FREED. 						     */
    /*************************************************************************/
    while (current < next)
    {
    	last = current;
    	current = current->size_ptr;
    }

    /*************************************************************************/
    /* COALLESCE WITH NEXT BLOCK IF POSSIBLE.                                */
    /*************************************************************************/
    if((long)next + next->packet_size + OVERHEAD == (long)current)
    {
    	next->size_ptr = current->size_ptr;
    	next->packet_size += -current->packet_size + OVERHEAD;
#ifdef DEBUG
    	current->guard = 0;
#endif
    }
    else
    {
    	next->size_ptr = current;	/* START TO PUT INTO LIST */
    }

    if(last)				/* ARE WE THE NEW HEAD OF THE LIST */
    {
        /*********************************************************************/
        /* WE ARE NOT THE HEAD OF THE LIST; TRY TO COALLESCE WITH LAST.      */
        /*********************************************************************/
    	if((long)last - last->packet_size + OVERHEAD == (long)next)
    	{
            last->size_ptr = next->size_ptr;
    	    last->packet_size += - next->packet_size - OVERHEAD;
#ifdef DEBUG
    	    next->guard = 0;
#endif
        }
        else
        {
            last->size_ptr = next;
    	    next->packet_size = - next->packet_size;
        }
    }
    else
    {
        far_sys_free = next;
    	next->packet_size = - next->packet_size;
    }
    _unlock();
}

/*****************************************************************************/
/*                                                                           */
/* FAR_REALLOC - Reallocate a packet to a new size.                          */
/*                                                                           */
/*****************************************************************************/
far void * far_realloc(far void * memblock, unsigned long newsize)
{
    far FPACKET * next;
    far FPACKET * userblock;
    far FPACKET * last;

    /****************************************************************/
    /* HANDLE SPECIAL CASES                                         */
    /****************************************************************/
    if( newsize == 0 )
    {
	far_free(memblock);
	return 0;
    }
    if( memblock == 0 )
	return far_malloc(newsize);

    /****************************************************************/
    /* ROUND SIZE UP TO EVEN BOUNDARY                               */
    /****************************************************************/
    if(newsize & 1)
	++newsize;

    _lock();

    userblock = (far FPACKET *)((far char *)memblock - OVERHEAD);
    next = (far FPACKET *)((far char *)memblock + userblock->packet_size);

    /****************************************************************/
    /* CHECK IF WE MUST MALLOC AND MOVE FOR THE FOLLOWING REASONS   */ 
    /* 1 IF THE USERBLOCK IS THE LAST BLOCK IN THE HEAP.            */
    /* 2 IF NEXT BLOCK IS NOT FREE.                                 */
    /* 3 IF NEXT BLOCK IS FREE BUT NOT BIG ENOUGH.                  */
    /*                                                              */
    /* NOTE ON CONDITION 1                                          */
    /*      IF THE USER BLOCK IS THE LAST BLOCK IN THE HEAP, THE    */
    /* NEXT BLOCK WILL BE JUST OUTSIDE THE HEAP.  SO THE FOLLOWING  */
    /* CONDITION IS USED:					    */
    /* ((far char*)next >= (far char*)far_sys_base + memsize)       */
    /*      THE COMPARISON IS REARRANGED FROM ITS NATURAL FORM TO   */
    /* AVOID THE COMPILER HANDLING ADDTION OF A VALUE > 64K TO A PTR*/
    /* ALSO, THE POINTERS ARE CASTED TO LONG TO AVOID A POINTER DIFF*/
    /* OF > 64K AS POINTER DIFFS ARE ALLOWD ONLY WITH IN ARRAY AND  */
    /* COMPILER LIMITS THE ARRAY SIZE TO BE 64K.                    */
    /****************************************************************/
    if( (newsize > userblock->packet_size) 
	   && ( ((long)next - (long)far_sys_base >= memsize) 
	   ||   (next->packet_size > 0) 
           ||   ((next->packet_size < 0) && 
          (newsize > userblock->packet_size - next->packet_size + OVERHEAD)) ) )
    {
	far void * ptr = far_malloc(newsize);
	if(ptr)
	{
	    far_memlcpy( memblock, ptr, userblock->packet_size );
	    far_free(memblock);
	}
	_unlock();
	return ptr;
    }

    /****************************************************************/
    /* IF WE ARE HERE, WE CAN REALLOC IN PLACE. WE MUST FIND NEXT   */
    /* AND LAST TO DO THE BOOKKEEPING				    */
    /****************************************************************/
    next = far_sys_free;
    last = 0;

    while (next < userblock)
    {
	last = next;
	next = next->size_ptr;
    }

    if((long)next == (long)memblock + userblock->packet_size)
    {
#ifdef DEBUG
	next->guard = 0;
#endif
	if( newsize >= userblock->packet_size - next->packet_size - MINSIZE )
	{
	    /****************************************************************/
	    /* COALLESCING WITH THE NEXT BLOCK - NEXT BLOCK IS COMPLETELY   */
	    /* ABSORBED.                                                    */
	    /****************************************************************/
	    last->size_ptr = next->size_ptr;
	    userblock->packet_size += -next->packet_size + OVERHEAD;
	}
	else
	{
	    /****************************************************************/
	    /* COALLESCING WITH THE NEXT BLOCK - WILL HAVE A CHUNK LEFTOVER */
	    /* ADD IT TO THE FREE LIST.                                     */
	    /****************************************************************/
	    long nsize = next->packet_size + newsize - userblock->packet_size;
	    far FPACKET* nextP = next->size_ptr;
	    next =	(far FPACKET*)((far char *)memblock + newsize);
	    next->packet_size = nsize;
	    next->size_ptr = nextP;
#ifdef DEBUG
	    next->guard = GUARDDWORD;
#endif
	    userblock->packet_size = newsize;
	    if(last)
		last->size_ptr = next;
	    else
		far_sys_free = next;
	}
    }
    else
    {
	/*********************************************************************/
	/* WE ARE SHRINKING IN PLACE IF THERE IS ENOUGH EXTRA TO MAKE A      */
	/* WORTHWHILE FREE BLOCK 					     */
	/*********************************************************************/
	if(userblock->packet_size - newsize >= OVERHEAD + MINSIZE)
	{
	    far FPACKET * nP = (far FPACKET*)((far char *)memblock + newsize);
	    nP->packet_size = - userblock->packet_size + newsize + OVERHEAD;
	    nP->size_ptr = next;
#ifdef DEBUG
	    nP->guard = GUARDDWORD;
#endif
	    if (last)
		last->size_ptr = nP;
	    else
 		far_sys_free = nP;
	    userblock->packet_size = newsize;
	}
    }
    _unlock();
    return memblock;
}

/*****************************************************************************/
/*                                                                           */
/* FAR_CALLOC - Allocate a packet of a given size, set the data in the       */
/*               packet to nulls, and return a pointer to it.                */
/*                                                                           */
/*****************************************************************************/
far void * far_calloc(unsigned long num, unsigned long size)
{
    register unsigned long i	    = size * num;
    register far void * ret = far_malloc(i);
    if(ret)
    {
	register far char * c = ret;
	while (i--) *c++ = 0;
    }
    return ret;
}


/*****************************************************************************/
/*                                                                           */
/*  FAR_CHKHEAP - Check the integrety of the far memory heap.  If the heap   */
/*                is corrupt, returns the address of the corrupt header, else*/
/*                returns 0.  Always returns 0 in release version.           */
/*                                                                           */
/*****************************************************************************/
long far_chkheap()
{
#ifdef DEBUG
    /* find the start of the heap */

    long pkt, top;

    pkt = (long)far_sys_base;
    top = (long) far_sys_base + memsize - sizeof(FPACKET);

    while( pkt < top)
    {
	if(((far FPACKET *)pkt)->guard != GUARDDWORD)
	{
	    _unlock();
	    return (long) &(((far FPACKET *)pkt)->guard);
	}

	if(((far FPACKET *)pkt)->packet_size > 0)
	    pkt += ((far FPACKET *)pkt)->packet_size + OVERHEAD;
	else
	    pkt += -((far FPACKET *)pkt)->packet_size + OVERHEAD;

    }
#endif
    _unlock();
    return 0;
}

/***************************************************************************/
/* FAR_MEMLMOVE - Version of memmove to move data in far memory 	   */
/* 		  (addresses >64K)  Can move more than 64K words.          */
/***************************************************************************/
far void *far_memlmove(far void *s1, far const void *s2, unsigned long n)
{
   if (s2 > s1)
      return far_memcpy(s1, s2, n);
   else
   {
      far unsigned char *st1 = (far unsigned char *)s1;
      far unsigned char *st2 = (far unsigned char *)s2;
      unsigned long      ln;

	  st1 = st1 + n;
	  st2 = st2 + n;
      for (ln = 0; ln < n; ln++) *--st1 = *--st2;
   }

   return s1;
}

/***************************************************************************/
/* FAR_MEMLCPY - Version of memcpy  to copy data in far memory )           */
/* 		 (addresses >64K). Can move more than 64K words.           */
/***************************************************************************/
void far *far_memlcpy(void far *to, const void far *from, unsigned long n)
{
     register char far *rto   = (char far *) to;
     register char far *rfrom = (char far *) from;
     register unsigned long rn;

     for (rn = 0; rn < n; rn++) *rto++ = *rfrom++;
     return (to);
}

/*****************************************************************************/
/*                                                                           */
/*  FAR_FREE_MEMORY - returns the total amount of free far memory available  */
/*                    for allocation.  The memory may be fragmented          */
/*                                                                           */
/*****************************************************************************/
long far_free_memory(void)
{
    far struct fpack *ptr;
    long memsz = 0;

    _lock();
    ptr = far_sys_free;

    if(!first_call)	/* IF MEMORY IS INITIALIZED */ 
    {
	while(ptr != LIMIT)
	{
	    memsz -= ptr->packet_size;
	    ptr = ptr->size_ptr;
	}
    }
    _unlock();
    return memsz;
}

/*****************************************************************************/
/*                                                                           */
/*  FAR_MAX_FREE - returns the size of the largest single block of far       */
/*                 memory available for allocation.                          */
/*                                                                           */
/*****************************************************************************/
long far_max_free(void)
{
    far struct fpack *ptr;
    long memsz = 0;

    _lock();
    ptr = far_sys_free;

    if(!first_call)	/* IF MEMORY IS INITIALIZED */
    {
	while(ptr != LIMIT)
	{
	    if(memsz > ptr->packet_size)
		memsz = ptr->packet_size;
	    ptr = ptr->size_ptr;
	}
    }
    _unlock();
    return -memsz;
}
