/****************************************************************************/
/*  farstrtod v6.1.0                                                         */
/*                                                                          */
/* Copyright (c) 1993-2012 Texas Instruments Incorporated                   */
/* http://www.ti.com/                                                       */
/*                                                                          */
/*  Redistribution and  use in source  and binary forms, with  or without   */
/*  modification,  are permitted provided  that the  following conditions   */
/*  are met:                                                                */
/*                                                                          */
/*     Redistributions  of source  code must  retain the  above copyright   */
/*     notice, this list of conditions and the following disclaimer.        */
/*                                                                          */
/*     Redistributions in binary form  must reproduce the above copyright   */
/*     notice, this  list of conditions  and the following  disclaimer in   */
/*     the  documentation  and/or   other  materials  provided  with  the   */
/*     distribution.                                                        */
/*                                                                          */
/*     Neither the  name of Texas Instruments Incorporated  nor the names   */
/*     of its  contributors may  be used to  endorse or  promote products   */
/*     derived  from   this  software  without   specific  prior  written   */
/*     permission.                                                          */
/*                                                                          */
/*  THIS SOFTWARE  IS PROVIDED BY THE COPYRIGHT  HOLDERS AND CONTRIBUTORS   */
/*  "AS IS"  AND ANY  EXPRESS OR IMPLIED  WARRANTIES, INCLUDING,  BUT NOT   */
/*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR   */
/*  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT   */
/*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,   */
/*  SPECIAL,  EXEMPLARY,  OR CONSEQUENTIAL  DAMAGES  (INCLUDING, BUT  NOT   */
/*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,   */
/*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY   */
/*  THEORY OF  LIABILITY, WHETHER IN CONTRACT, STRICT  LIABILITY, OR TORT   */
/*  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE   */
/*  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.    */
/*                                                                          */
/****************************************************************************/
#include <stdlib.h>
#include <ctype.h>
#include <float.h>
#include <errno.h>
#include <math.h>

static const _DATA_ACCESS double far_powerof10[] = { 1.e1, 1.e2, 1.e4, 1.e8, 
								1.e16, 1.e32 };
static const _DATA_ACCESS double far_digits[]    = { 0, 1, 2, 3, 4, 
								5, 6, 7, 8, 9 };

double far_strtod(const far char *st, far char **endptr)
{
    double          result = 0;
    const far char *fst    = st;
    int             exp    = 0;               /* EXPONENT              */
    int         count;                    /* EXPONENT CALCULATION  */
    int             value  = 0;               /* SUCCESSFUL PARSE      */
    int         sign;

    while (_isspace(*fst)) ++fst;  /* SKIP WHITE SPACE */
    if ((sign = (*fst == '-')) || *fst == '+') { ++fst; value = 1; }

    /*----------------------------------------------------------------------*/
    /* READ IN FRACTIONAL PART OF NUMBER, UNTIL AN 'E' IS REACHED.          */
    /* COUNT DIGITS AFTER DECIMAL POINT.                                    */
    /*----------------------------------------------------------------------*/
    while (_isdigit(*fst))
    {
       result = result * 10 + far_digits[*fst++ - '0']; 
       value  = 1;
    }

    if (*fst == '.')
    {
       ++fst;
       while (_isdigit(*fst)) 
       {
          result = result * 10 + far_digits[*fst++ - '0']; 
          value  = 1;
	  --exp;
       }
    }

    if (sign) result = -result;  /* IF NEGATIVE NUMBER, REVERSE SIGN */

    /*----------------------------------------------------------------------*/
    /* READ IN EXPLICIT EXPONENT AND CALCULATE REAL EXPONENT.               */
    /*----------------------------------------------------------------------*/
    if (value && _toupper(*fst) == 'E')
    {
       int i; /* DON'T LET EXPONENT OVERFLOW */

       if ((sign = (*++fst == '-')) || *fst == '+') ++fst;

       for (i = count = 0; _isdigit(*fst) && i < 3; i++)
	  { count *= 10; count += *fst++ - '0'; }

       while (_isdigit(*fst)) fst++;

       if (sign) exp -= count;
       else      exp += count;
    }

    /*----------------------------------------------------------------------*/
    /* ADJUST NUMBER BY POWERS OF TEN SPECIFIED BY FORMAT AND EXPONENT.     */
    /*----------------------------------------------------------------------*/
    if (result != 0.0)
    {
       if (exp > DBL_MAX_10_EXP) 
	  { errno = ERANGE; result = (result < 0) ? -HUGE_VAL : HUGE_VAL; }
       else if (exp < DBL_MIN_10_EXP) 
	  { errno = ERANGE; result = 0.0; }
       else if (exp < 0)
	  for (count = 0, exp = -exp; exp; count++, exp >>= 1)
	     {  if (exp & 1) result /= far_powerof10[count]; }
       else
	  for (count = 0; exp; count++, exp >>= 1)
	     {  if (exp & 1) result *= far_powerof10[count]; }
    }

    if (endptr) *endptr = (far char *)(value ? fst : st);
    return result;
}
